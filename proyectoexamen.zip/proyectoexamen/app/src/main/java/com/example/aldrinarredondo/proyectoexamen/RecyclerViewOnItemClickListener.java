package com.example.aldrinarredondo.proyectoexamen;

import android.view.View;

public interface RecyclerViewOnItemClickListener {
    void onClick(View v, int posicion, int elemento);
}
